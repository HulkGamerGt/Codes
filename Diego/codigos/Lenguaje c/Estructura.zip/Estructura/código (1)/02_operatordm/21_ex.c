
// Types of increment operator 

#include <stdio.h>

int main() {
  int x = 10;

  int y = 10 + ++x;

  printf("x = %d, y = %d\n", x, y);

  return 0;
}