
// Return pointer from function

#include <stdio.h>
#include <time.h>
#include <stdlib.h>

/* function to generate and return random numbers */
int *getRandom() {
   static int  r[10];
   srand((unsigned)time(NULL));    /* set the seed */
  
   for(int i = 0; i < 10; ++i){
      r[i] = rand();
   }
    
   return r;
}

int main(){

   int *p;     /* a pointer to an int */
   p = getRandom();

   for(int i = 0; i < 10; i++) {
      printf("*(p + %d): %d\n", i, *(p + i));
   }

   return 0;
}