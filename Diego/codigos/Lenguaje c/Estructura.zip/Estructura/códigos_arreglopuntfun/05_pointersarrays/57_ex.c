
// NULL Pointer

#include <stdio.h> 

int main() {
   int *p= NULL;//initialize the pointer as null.
   printf("The value of pointer is %u",p);
   return 0;
}
