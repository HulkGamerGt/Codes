#include <stdio.h>
#include <stdlib.h>

typedef struct node{
    int data;
    node *leftChild;
    node *rightChild;
}node;

node *root = NULL;

void insert(int data){
    node *tempNode = (node*) malloc(sizeof(node));
    node *current;
    node *parent;

    tempNode->data = data;
    tempNode->leftChild = NULL;
    tempNode->rightChild = NULL;

    if(root == NULL){
        root = tempNode;
    }else{
        current = root;
        parent = NULL;
        
        while (1) {
            parent = current;
            
            if(data < parent->data){
                current = current->leftChild;
                if(current == NULL){
                    parent->leftChild = tempNode;
                    return;
                }
            }else{
                current = current->rightChild;
                if(current == NULL){
                    parent->rightChild = tempNode;
                    return;
                }
            }
        }
    }
}

void pre_order_traversal(node* root) {
    if (root != NULL) {
        printf("%d ", root->data);
        pre_order_traversal(root->leftChild);
        pre_order_traversal(root->rightChild);
    }
}