#include <stdio.h>
#include "grafo.h"
#include "distancias.h"
#include "mst.h"
#include "salida.h"

/* =====================================================================
 * NOTA IMPORTANTE:
 * Las coordenadas de "puntos_ejemplo" son ILUSTRATIVAS, solo para
 * demostrar que el codigo compila y funciona correctamente. Segun el
 * enunciado (paso 1), el grupo debe reemplazar esta lista por 25
 * puntos de interes REALES de la ciudad chilena elegida, verificados
 * en Google Maps / OpenStreetMap.
 * ===================================================================== */

typedef struct { const char *nombre; double lat; double lon; } PuntoInteres;

static PuntoInteres puntos_ejemplo[25] = {
    {"Plaza de Armas",                 -35.4264, -71.6554},
    {"Universidad Catolica del Maule", -35.4283, -71.6536},
    {"Universidad de Talca",           -35.3961, -71.6645},
    {"Terminal de Buses",              -35.4233, -71.6602},
    {"Hospital Regional",              -35.4350, -71.6489},
    {"Mall Plaza Maule",               -35.4072, -71.6390},
    {"Estadio Fiscal",                 -35.4189, -71.6612},
    {"Parque Ibanez",                  -35.4310, -71.6480},
    {"Estacion de Trenes",             -35.4233, -71.6610},
    {"Museo OBrien",                   -35.4267, -71.6541},
    {"Costanera Centro",               -35.4055, -71.6378},
    {"Liceo Abate Molina",             -35.4280, -71.6560},
    {"Catedral de Talca",              -35.4267, -71.6552},
    {"Av. San Miguel",                 -35.4150, -71.6500},
    {"Feria Modelo",                   -35.4220, -71.6650},
    {"Centro Historico",               -35.4260, -71.6545},
    {"Parque OHiggins",                -35.4310, -71.6440},
    {"Villa Cultural Huilquilemu",     -35.4690, -71.5550},
    {"Cementerio Parque",              -35.4400, -71.6300},
    {"Casino de Talca",                -35.4100, -71.6420},
    {"Cerro La Virgen",                -35.4330, -71.6700},
    {"Plaza Italia",                   -35.4275, -71.6500},
    {"Estadio Bicentenario",           -35.4150, -71.6650},
    {"Aerodromo",                      -35.3950, -71.6900},
    {"Camino a San Clemente",          -35.4500, -71.6100}
};

int main(void) {
    /* Archivo de salida: todo lo impreso en consola tambien queda aqui,
     * para usarlo como evidencia de "prueba de ejecucion" en el informe. */
    FILE *salida = fopen("resultado_ejercicio1.txt", "w");
    if (!salida) {
        printf("Aviso: no se pudo crear resultado_ejercicio1.txt, se continua solo con consola.\n");
    }

    Grafo g;
    grafo_inicializar(&g);

    for (int i = 0; i < 25; i++)
        grafo_agregar_nodo(&g, puntos_ejemplo[i].nombre, puntos_ejemplo[i].lat, puntos_ejemplo[i].lon);

    /* Grafo COMPLETO: una arista entre cada par de POIs, con peso igual
     * a la distancia euclidiana aproximada (en km) entre sus coordenadas. */
    for (int i = 0; i < g.num_nodos; i++)
        for (int j = i + 1; j < g.num_nodos; j++) {
            double peso = distancia_euclidiana_aprox(g.nodos[i].lat, g.nodos[i].lon,
                                                       g.nodos[j].lat, g.nodos[j].lon);
            grafo_agregar_arista(&g, i, j, peso);
        }

    imprimir_doble(salida, "=== Nodos (Puntos de interes) ===\n");
    grafo_imprimir_nodos(&g, salida);

    imprimir_doble(salida, "\n=== Matriz de adyacencia (25x25, pesos en km) ===\n");
    grafo_imprimir_matriz(&g, salida);

    ArbolExpansion arbol_prim    = mst_prim(&g, 0);
    ArbolExpansion arbol_kruskal = mst_kruskal(&g);
    ArbolExpansion arbol_boruvka = mst_boruvka(&g);

    imprimir_doble(salida, "\n");
    mst_imprimir(&arbol_prim, &g, "PRIM", salida);
    imprimir_doble(salida, "\n");
    mst_imprimir(&arbol_kruskal, &g, "KRUSKAL", salida);
    imprimir_doble(salida, "\n");
    mst_imprimir(&arbol_boruvka, &g, "BORUVKA", salida);

    imprimir_doble(salida, "\n=== Comparacion de pesos totales (distancia total) ===\n");
    mst_comparar3(&arbol_prim, &arbol_kruskal, &arbol_boruvka, salida);

    if (salida) {
        fclose(salida);
        printf("\n[Resultado completo tambien guardado en resultado_ejercicio1.txt]\n");
    }

    return 0;
}
