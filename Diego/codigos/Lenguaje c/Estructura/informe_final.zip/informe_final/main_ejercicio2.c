#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "grafo.h"
#include "distancias.h"
#include "caminos_minimos.h"
#include "grasp_tsp.h"
#include "salida.h"

/* =====================================================================
 * NOTA IMPORTANTE:
 * Las 5 zonas y las 10 ubicaciones de cada una son ILUSTRATIVAS, solo
 * para demostrar que el codigo compila y funciona correctamente. Segun
 * el enunciado, el grupo debe escoger y verificar en Google Maps sus
 * propias zonas y ubicaciones reales dentro de Talca, incluyendo la
 * ubicacion real de la UCM (que debe ser una de las 50 ubicaciones).
 * ===================================================================== */

#define NUM_ZONAS        5
#define NODOS_POR_ZONA   10
#define ZONA_UCM         0   /* la UCM se ubica en la zona 0 ... */
#define POS_UCM          0   /* ... en la posicion 0 de esa zona  */

typedef struct { const char *nombre; double lat; double lon; } Ubicacion;

static Ubicacion zonas_ejemplo[NUM_ZONAS][NODOS_POR_ZONA] = {
    /* Zona 0: Centro / UCM */
    {
        {"UCM - Campus Talca",       -35.4283, -71.6536},
        {"Plaza de Armas",           -35.4264, -71.6554},
        {"Catedral de Talca",        -35.4267, -71.6552},
        {"Museo OBrien",             -35.4267, -71.6541},
        {"Liceo Abate Molina",       -35.4280, -71.6560},
        {"Centro Comercial Centro",  -35.4258, -71.6548},
        {"Biblioteca Regional",      -35.4270, -71.6530},
        {"Mercado Central",          -35.4250, -71.6570},
        {"Casa de la Cultura",       -35.4275, -71.6520},
        {"Edificio Consistorial",    -35.4262, -71.6558}
    },
    /* Zona 1: Sur / Universidad de Talca */
    {
        {"Universidad de Talca",     -35.3961, -71.6645},
        {"Parque Los Reyes",         -35.3990, -71.6600},
        {"Estadio Bicentenario",     -35.4150, -71.6650},
        {"Villa Las Lilas",          -35.4020, -71.6620},
        {"Centro Deportivo Sur",     -35.4050, -71.6680},
        {"Liceo Sur",                -35.4000, -71.6700},
        {"Plaza Sur",                -35.4080, -71.6630},
        {"Hospital Sur",             -35.4070, -71.6590},
        {"Feria Sur",                -35.4040, -71.6710},
        {"Colegio San Agustin",      -35.4010, -71.6660}
    },
    /* Zona 2: Norte / Terminal */
    {
        {"Terminal de Buses",        -35.4233, -71.6602},
        {"Feria Modelo",             -35.4220, -71.6650},
        {"Estacion de Trenes",       -35.4233, -71.6610},
        {"Parque Norte",             -35.4180, -71.6620},
        {"Villa Norte",              -35.4160, -71.6680},
        {"Colegio Norte",            -35.4200, -71.6660},
        {"Cementerio Municipal",     -35.4150, -71.6600},
        {"Plaza Norte",              -35.4190, -71.6590},
        {"Centro de Salud Norte",    -35.4210, -71.6640},
        {"Av. San Miguel",           -35.4150, -71.6500}
    },
    /* Zona 3: Oriente / Mall */
    {
        {"Mall Plaza Maule",         -35.4072, -71.6390},
        {"Costanera Centro",         -35.4055, -71.6378},
        {"Casino de Talca",          -35.4100, -71.6420},
        {"Parque Ibanez",            -35.4310, -71.6480},
        {"Hospital Regional",        -35.4350, -71.6489},
        {"Plaza Italia",             -35.4275, -71.6500},
        {"Colegio Oriente",          -35.4150, -71.6450},
        {"Villa Oriente",            -35.4200, -71.6400},
        {"Centro Medico Oriente",    -35.4230, -71.6440},
        {"Parque OHiggins",          -35.4310, -71.6440}
    },
    /* Zona 4: Poniente */
    {
        {"Cerro La Virgen",          -35.4330, -71.6700},
        {"Villa Poniente",           -35.4290, -71.6750},
        {"Colegio Poniente",         -35.4350, -71.6720},
        {"Parque Poniente",          -35.4310, -71.6800},
        {"Plaza Poniente",           -35.4270, -71.6780},
        {"Centro Comunitario",       -35.4380, -71.6650},
        {"Feria Poniente",           -35.4250, -71.6820},
        {"Estadio Fiscal",           -35.4189, -71.6612},
        {"Villa Don Bosco",          -35.4400, -71.6700},
        {"Camino a San Clemente",    -35.4500, -71.6100}
    }
};

int main(void) {
    srand((unsigned int) time(NULL));

    /* Archivo de salida: todo lo impreso en consola tambien queda aqui,
     * para usarlo como evidencia de "prueba de ejecucion" en el informe. */
    FILE *salida = fopen("resultado_ejercicio2.txt", "w");
    if (!salida) {
        printf("Aviso: no se pudo crear resultado_ejercicio2.txt, se continua solo con consola.\n");
    }

    Grafo g;
    grafo_inicializar(&g);

    int id_global[NUM_ZONAS][NODOS_POR_ZONA];
    for (int z = 0; z < NUM_ZONAS; z++)
        for (int p = 0; p < NODOS_POR_ZONA; p++)
            id_global[z][p] = grafo_agregar_nodo(&g, zonas_ejemplo[z][p].nombre,
                                                  zonas_ejemplo[z][p].lat, zonas_ejemplo[z][p].lon);

    /* 1) Todas las ubicaciones DENTRO de una misma zona quedan conectadas
     *    entre si (subgrafo completo K10 por zona), peso = Haversine. */
    for (int z = 0; z < NUM_ZONAS; z++) {
        for (int i = 0; i < NODOS_POR_ZONA; i++) {
            for (int j = i + 1; j < NODOS_POR_ZONA; j++) {
                int a = id_global[z][i], b = id_global[z][j];
                double peso = distancia_haversine(g.nodos[a].lat, g.nodos[a].lon,
                                                   g.nodos[b].lat, g.nodos[b].lon);
                grafo_agregar_arista(&g, a, b, peso);
            }
        }
    }

    /* 2) Al menos 3 conexiones entre ubicaciones de zonas DISTINTAS
     *    (aqui se agregan 4 para mayor conectividad del grafo). */
    int enlaces_inter_zona[4][2] = {
        { id_global[0][1], id_global[1][2] },
        { id_global[1][5], id_global[2][3] },
        { id_global[2][7], id_global[3][4] },
        { id_global[3][2], id_global[4][6] }
    };
    for (int i = 0; i < 4; i++) {
        int a = enlaces_inter_zona[i][0], b = enlaces_inter_zona[i][1];
        double peso = distancia_haversine(g.nodos[a].lat, g.nodos[a].lon,
                                           g.nodos[b].lat, g.nodos[b].lon);
        grafo_agregar_arista(&g, a, b, peso);
    }

    imprimir_doble(salida, "=== Nodos (5 zonas x 10 ubicaciones) ===\n");
    grafo_imprimir_nodos(&g, salida);

    int nodo_ucm = id_global[ZONA_UCM][POS_UCM];
    imprimir_doble(salida, "\nNodo UCM (inicio y fin del recorrido): %d - %s\n", nodo_ucm, g.nodos[nodo_ucm].nombre);

    /* El grafo NO es completo (solo 4 enlaces inter-zona), por lo que se
     * calculan las distancias minimas entre TODO par de nodos antes de
     * aplicar GRASP (que necesita poder "comparar" cualquier par). */
    CaminosMinimos cm;
    floyd_warshall(&g, &cm);

    Circuito mejor = grasp_tsp(&g, &cm, nodo_ucm, /*iteraciones=*/200, /*alpha=*/0.3);

    imprimir_doble(salida, "\n=== Mejor circuito encontrado (GRASP, 200 iteraciones, alpha=0.3) ===\n");
    grasp_imprimir_circuito(&mejor, &g, salida);

    if (salida) {
        fclose(salida);
        printf("\n[Resultado completo tambien guardado en resultado_ejercicio2.txt]\n");
    }

    return 0;
}
