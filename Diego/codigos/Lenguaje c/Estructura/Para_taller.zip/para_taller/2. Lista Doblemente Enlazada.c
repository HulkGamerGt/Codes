#include <stdio.h>
#include <stdlib.h>

typedef struct NodoDoble {
    int dato;
    struct NodoDoble* anterior;
    struct NodoDoble* siguiente;
} NodoDoble;

typedef struct {
    NodoDoble* cabeza;
    NodoDoble* cola;
    int tam;
} ListaDoble;

void inicializarListaDoble(ListaDoble* l) {
    l->cabeza = l->cola = NULL;
    l->tam = 0;
}

NodoDoble* crearNodoDoble(int dato) {
    NodoDoble* n = (NodoDoble*)malloc(sizeof(NodoDoble));
    if (!n) {
        printf("Error: memoria insuficiente para nodo doble.\n");
        return NULL;
    }
    n->dato = dato;
    n->anterior = n->siguiente = NULL;
    return n;
}

int insertarInicioDoble(ListaDoble* l, int dato) {
    NodoDoble* n = crearNodoDoble(dato);
    if (!n) return 0;
    n->siguiente = l->cabeza;
    if (l->cabeza) l->cabeza->anterior = n;
    else l->cola = n;
    l->cabeza = n;
    l->tam++;
    return 1;
}

int insertarFinalDoble(ListaDoble* l, int dato) {
    NodoDoble* n = crearNodoDoble(dato);
    if (!n) return 0;
    if (!l->cola) {
        l->cabeza = l->cola = n;
    } else {
        l->cola->siguiente = n;
        n->anterior = l->cola;
        l->cola = n;
    }
    l->tam++;
    return 1;
}

int insertarOrdenadoDoble(ListaDoble* l, int dato) {
    NodoDoble* n = crearNodoDoble(dato);
    if (!n) return 0;
    if (!l->cabeza || l->cabeza->dato >= dato) {
        n->siguiente = l->cabeza;
        if (l->cabeza) l->cabeza->anterior = n;
        else l->cola = n;
        l->cabeza = n;
    } else {
        NodoDoble* act = l->cabeza;
        while (act->siguiente && act->siguiente->dato < dato)
            act = act->siguiente;
        n->siguiente = act->siguiente;
        n->anterior = act;
        if (act->siguiente) act->siguiente->anterior = n;
        else l->cola = n;
        act->siguiente = n;
    }
    l->tam++;
    return 1;
}

int insertarPosicionDoble(ListaDoble* l, int dato, int pos) {
    if (pos < 0 || pos > l->tam) return 0;
    if (pos == 0) return insertarInicioDoble(l, dato);
    if (pos == l->tam) return insertarFinalDoble(l, dato);
    NodoDoble* act = l->cabeza;
    for (int i = 0; i < pos; i++) act = act->siguiente;
    NodoDoble* n = crearNodoDoble(dato);
    if (!n) return 0;
    n->siguiente = act;
    n->anterior = act->anterior;
    act->anterior->siguiente = n;
    act->anterior = n;
    l->tam++;
    return 1;
}

int eliminarDatoDoble(ListaDoble* l, int dato) {
    NodoDoble* act = l->cabeza;
    while (act) {
        if (act->dato == dato) {
            if (act->anterior) act->anterior->siguiente = act->siguiente;
            else l->cabeza = act->siguiente;
            if (act->siguiente) act->siguiente->anterior = act->anterior;
            else l->cola = act->anterior;
            free(act);
            l->tam--;
            return 1;
        }
        act = act->siguiente;
    }
    return 0;
}

int eliminarPosicionDoble(ListaDoble* l, int pos) {
    if (pos < 0 || pos >= l->tam) return 0;
    NodoDoble* act = l->cabeza;
    for (int i = 0; i < pos; i++) act = act->siguiente;
    if (act->anterior) act->anterior->siguiente = act->siguiente;
    else l->cabeza = act->siguiente;
    if (act->siguiente) act->siguiente->anterior = act->anterior;
    else l->cola = act->anterior;
    free(act);
    l->tam--;
    return 1;
}

int buscarDoble(ListaDoble* l, int dato) {
    NodoDoble* p = l->cabeza;
    while (p) {
        if (p->dato == dato) return 1;
        p = p->siguiente;
    }
    return 0;
}

int longitudDoble(ListaDoble* l) { return l->tam; }

void mostrarAdelante(ListaDoble* l) {
    NodoDoble* p = l->cabeza;
    while (p) {
        printf("%d <-> ", p->dato);
        p = p->siguiente;
    }
    printf("NULL (tam=%d)\n", l->tam);
}

void mostrarAtras(ListaDoble* l) {
    NodoDoble* p = l->cola;
    while (p) {
        printf("%d <-> ", p->dato);
        p = p->anterior;
    }
    printf("NULL (tam=%d)\n", l->tam);
}

int copiarListaDoble(ListaDoble* origen, ListaDoble* destino) {
    inicializarListaDoble(destino);
    NodoDoble* p = origen->cabeza;
    while (p) {
        if (!insertarFinalDoble(destino, p->dato)) {
            liberarListaDoble(destino);
            return 0;
        }
        p = p->siguiente;
    }
    return 1;
}

void invertirDoble(ListaDoble* l) {
    NodoDoble* act = l->cabeza;
    l->cola = l->cabeza;
    while (act) {
        NodoDoble* temp = act->siguiente;
        act->siguiente = act->anterior;
        act->anterior = temp;
        act = temp;
    }
    if (l->cola) {
        l->cabeza = l->cola;
        while (l->cabeza->anterior) l->cabeza = l->cabeza->anterior;
    }
}

void liberarListaDoble(ListaDoble* l) {
    NodoDoble* act = l->cabeza;
    while (act) {
        NodoDoble* temp = act;
        act = act->siguiente;
        free(temp);
    }
    l->cabeza = l->cola = NULL;
    l->tam = 0;
}

void concatenarDoble(ListaDoble* l1, ListaDoble* l2) {
    if (!l2->cabeza) return;
    if (!l1->cabeza) {
        l1->cabeza = l2->cabeza;
        l1->cola = l2->cola;
    } else {
        l1->cola->siguiente = l2->cabeza;
        l2->cabeza->anterior = l1->cola;
        l1->cola = l2->cola;
    }
    l1->tam += l2->tam;
    l2->cabeza = l2->cola = NULL;
    l2->tam = 0;
}

// --- MergeSort para lista doble ---
NodoDoble* dividirDoble(NodoDoble* cabeza) {
    NodoDoble* rapido = cabeza->siguiente;
    NodoDoble* lento = cabeza;
    while (rapido) {
        rapido = rapido->siguiente;
        if (rapido) {
            lento = lento->siguiente;
            rapido = rapido->siguiente;
        }
    }
    NodoDoble* mitad = lento->siguiente;
    if (mitad) mitad->anterior = NULL;
    lento->siguiente = NULL;
    return mitad;
}

NodoDoble* fusionarDoble(NodoDoble* a, NodoDoble* b) {
    if (!a) return b;
    if (!b) return a;
    if (a->dato <= b->dato) {
        a->siguiente = fusionarDoble(a->siguiente, b);
        if (a->siguiente) a->siguiente->anterior = a;
        a->anterior = NULL;
        return a;
    } else {
        b->siguiente = fusionarDoble(a, b->siguiente);
        if (b->siguiente) b->siguiente->anterior = b;
        b->anterior = NULL;
        return b;
    }
}

void mergeSortDobleRec(NodoDoble** cabezaRef) {
    NodoDoble* cabeza = *cabezaRef;
    if (!cabeza || !cabeza->siguiente) return;
    NodoDoble* mitad = dividirDoble(cabeza);
    mergeSortDobleRec(&cabeza);
    mergeSortDobleRec(&mitad);
    *cabezaRef = fusionarDoble(cabeza, mitad);
}

void mergeSortDoble(ListaDoble* l) {
    mergeSortDobleRec(&(l->cabeza));
    if (!l->cabeza) {
        l->cola = NULL;
        return;
    }
    l->cola = l->cabeza;
    while (l->cola->siguiente) l->cola = l->cola->siguiente;
}

void eliminarDuplicadosDoble(ListaDoble* l) {
    NodoDoble* act = l->cabeza;
    while (act && act->siguiente) {
        if (act->dato == act->siguiente->dato) {
            NodoDoble* tmp = act->siguiente;
            act->siguiente = tmp->siguiente;
            if (tmp->siguiente) tmp->siguiente->anterior = act;
            else l->cola = act;
            free(tmp);
            l->tam--;
        } else {
            act = act->siguiente;
        }
    }
}

// Reemplazar el dato de un nodo en una posición dada
int reemplazarDoble(ListaDoble* l, int pos, int nuevoDato) {
    if (pos < 0 || pos >= l->tam) return 0;
    NodoDoble* act = l->cabeza;
    for (int i = 0; i < pos; i++) act = act->siguiente;
    act->dato = nuevoDato;
    return 1;
}

// Mueve un nodo de una posición a otra (extrae y reubica)
int moverNodo(ListaDoble* l, int posOrigen, int posDestino) {
    if (posOrigen < 0 || posOrigen >= l->tam || posDestino < 0 || posDestino > l->tam)
        return 0;
    if (posOrigen == posDestino) return 1;
    // Extraer nodo en posOrigen
    NodoDoble* nodo = l->cabeza;
    for (int i = 0; i < posOrigen; i++) nodo = nodo->siguiente;
    if (nodo->anterior) nodo->anterior->siguiente = nodo->siguiente;
    else l->cabeza = nodo->siguiente;
    if (nodo->siguiente) nodo->siguiente->anterior = nodo->anterior;
    else l->cola = nodo->anterior;
    // Insertar en posDestino (ajustada si es necesario)
    if (posDestino == 0) {
        nodo->siguiente = l->cabeza;
        nodo->anterior = NULL;
        if (l->cabeza) l->cabeza->anterior = nodo;
        else l->cola = nodo;
        l->cabeza = nodo;
    } else if (posDestino == l->tam - 1) { // ya reducido en 1 al extraer
        nodo->siguiente = NULL;
        nodo->anterior = l->cola;
        l->cola->siguiente = nodo;
        l->cola = nodo;
    } else {
        NodoDoble* ref = l->cabeza;
        for (int i = 0; i < posDestino; i++) ref = ref->siguiente;
        nodo->siguiente = ref;
        nodo->anterior = ref->anterior;
        ref->anterior->siguiente = nodo;
        ref->anterior = nodo;
    }
    return 1;
}

// Hacer la lista circular doble
void hacerCircularDoble(ListaDoble* l) {
    if (!l->cabeza) return;
    l->cola->siguiente = l->cabeza;
    l->cabeza->anterior = l->cola;
    l->cola = NULL; // circular ya no tiene cola lineal
}

// Romper circularidad
void deshacerCircularDoble(ListaDoble* l) {
    if (!l->cabeza) return;
    NodoDoble* ultimo = l->cabeza;
    while (ultimo->siguiente && ultimo->siguiente != l->cabeza)
        ultimo = ultimo->siguiente;
    if (ultimo->siguiente == l->cabeza) {
        ultimo->siguiente = NULL;
        l->cabeza->anterior = NULL;
        l->cola = ultimo;
    }
}

// ---------- MAIN DE PRUEBA ----------
int main() {
    ListaDoble lista;
    inicializarListaDoble(&lista);
    int opcion, valor, pos;

    do {
        printf("\n--- MENU LISTA DOBLE ---\n");
        printf("1. Insertar al inicio\n");
        printf("2. Insertar al final\n");
        printf("3. Insertar ordenado\n");
        printf("4. Insertar en posicion\n");
        printf("5. Eliminar por valor\n");
        printf("6. Eliminar por posicion\n");
        printf("7. Buscar\n");
        printf("8. Mostrar adelante\n");
        printf("9. Mostrar atras\n");
        printf("10. Invertir\n");
        printf("11. Ordenar (MergeSort)\n");
        printf("12. Copiar a otra lista\n");
        printf("13. Concatenar con lista auxiliar\n");
        printf("14. Reemplazar dato en posicion\n");
        printf("15. Mover nodo\n");
        printf("16. Hacer circular\n");
        printf("17. Deshacer circular\n");
        printf("0. Salir\n");
        printf("Elija: ");
        scanf("%d", &opcion);

        switch(opcion) {
            case 1:
                printf("Valor: "); scanf("%d", &valor);
                insertarInicioDoble(&lista, valor);
                break;
            case 2:
                printf("Valor: "); scanf("%d", &valor);
                insertarFinalDoble(&lista, valor);
                break;
            case 3:
                printf("Valor: "); scanf("%d", &valor);
                insertarOrdenadoDoble(&lista, valor);
                break;
            case 4:
                printf("Valor y posicion: "); scanf("%d %d", &valor, &pos);
                if (!insertarPosicionDoble(&lista, valor, pos))
                    printf("Posicion invalida\n");
                break;
            case 5:
                printf("Valor a eliminar: "); scanf("%d", &valor);
                if (eliminarDatoDoble(&lista, valor))
                    printf("Eliminado\n");
                else
                    printf("No encontrado\n");
                break;
            case 6:
                printf("Posicion a eliminar: "); scanf("%d", &pos);
                if (!eliminarPosicionDoble(&lista, pos))
                    printf("Posicion invalida\n");
                break;
            case 7:
                printf("Valor a buscar: "); scanf("%d", &valor);
                printf(buscarDoble(&lista, valor) ? "Encontrado\n" : "No encontrado\n");
                break;
            case 8:
                mostrarAdelante(&lista);
                break;
            case 9:
                mostrarAtras(&lista);
                break;
            case 10:
                invertirDoble(&lista);
                printf("Lista invertida.\n");
                break;
            case 11:
                mergeSortDoble(&lista);
                printf("Ordenada con MergeSort.\n");
                break;
            case 12: {
                ListaDoble copia;
                if (copiarListaDoble(&lista, &copia)) {
                    printf("Copia: ");
                    mostrarAdelante(&copia);
                    liberarListaDoble(&copia);
                }
                break;
            }
            case 13: {
                ListaDoble aux;
                inicializarListaDoble(&aux);
                int n;
                printf("Cuantos elementos en lista auxiliar? ");
                scanf("%d", &n);
                for (int i = 0; i < n; i++) {
                    printf("Elemento %d: ", i+1);
                    scanf("%d", &valor);
                    insertarFinalDoble(&aux, valor);
                }
                concatenarDoble(&lista, &aux);
                printf("Listas concatenadas.\n");
                break;
            }
            case 14:
                printf("Posicion y nuevo valor: "); scanf("%d %d", &pos, &valor);
                if (!reemplazarDoble(&lista, pos, valor))
                    printf("Posicion invalida\n");
                break;
            case 15: {
                int orig, dest;
                printf("Posicion origen y destino: "); scanf("%d %d", &orig, &dest);
                if (!moverNodo(&lista, orig, dest))
                    printf("Error al mover\n");
                break;
            }
            case 16:
                hacerCircularDoble(&lista);
                printf("Lista vuelta circular (no usar mostrar normal).\n");
                break;
            case 17:
                deshacerCircularDoble(&lista);
                printf("Circularidad deshecha.\n");
                break;
            case 0:
                break;
            default:
                printf("Opcion invalida\n");
        }
    } while (opcion != 0);

    liberarListaDoble(&lista);
    return 0;
}