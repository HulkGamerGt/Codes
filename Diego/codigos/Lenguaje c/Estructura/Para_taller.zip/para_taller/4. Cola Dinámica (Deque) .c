#include <stdio.h>
#include <stdlib.h>

typedef struct NodoDeque {
    int dato;
    struct NodoDeque* anterior;
    struct NodoDeque* siguiente;
} NodoDeque;

typedef struct {
    NodoDeque* frente;
    NodoDeque* final;
    int tam;
} Deque;

void inicializarDeque(Deque* d) { d->frente = d->final = NULL; d->tam = 0; }
int dequeVacio(const Deque* d) { return d->frente == NULL; }

int encolarFrente(Deque* d, int dato) {
    NodoDeque* n = (NodoDeque*)malloc(sizeof(NodoDeque));
    if (!n) { printf("Error de memoria.\n"); return 0; }
    n->dato = dato;
    n->anterior = NULL;
    n->siguiente = d->frente;
    if (d->frente) d->frente->anterior = n;
    else d->final = n;
    d->frente = n;
    d->tam++;
    return 1;
}

int encolarFinal(Deque* d, int dato) {
    NodoDeque* n = (NodoDeque*)malloc(sizeof(NodoDeque));
    if (!n) { printf("Error de memoria.\n"); return 0; }
    n->dato = dato;
    n->siguiente = NULL;
    n->anterior = d->final;
    if (d->final) d->final->siguiente = n;
    else d->frente = n;
    d->final = n;
    d->tam++;
    return 1;
}

int desencolarFrente(Deque* d, int* dato) {
    if (dequeVacio(d)) { printf("Error: deque vacío.\n"); return 0; }
    NodoDeque* tmp = d->frente;
    *dato = tmp->dato;
    d->frente = tmp->siguiente;
    if (d->frente) d->frente->anterior = NULL;
    else d->final = NULL;
    free(tmp);
    d->tam--;
    return 1;
}

int desencolarFinal(Deque* d, int* dato) {
    if (dequeVacio(d)) { printf("Error: deque vacío.\n"); return 0; }
    NodoDeque* tmp = d->final;
    *dato = tmp->dato;
    d->final = tmp->anterior;
    if (d->final) d->final->siguiente = NULL;
    else d->frente = NULL;
    free(tmp);
    d->tam--;
    return 1;
}

int verFrente(const Deque* d, int* dato) {
    if (dequeVacio(d)) return 0;
    *dato = d->frente->dato;
    return 1;
}

int verFinal(const Deque* d, int* dato) {
    if (dequeVacio(d)) return 0;
    *dato = d->final->dato;
    return 1;
}

int tamanioDeque(const Deque* d) { return d->tam; }

void mostrarDeque(const Deque* d) {
    const NodoDeque* p = d->frente;
    printf("Frente -> ");
    while (p) {
        printf("%d ", p->dato);
        p = p->siguiente;
    }
    printf("<- Final (tam=%d)\n", d->tam);
}

int buscarEnDeque(const Deque* d, int dato) {
    const NodoDeque* p = d->frente;
    while (p) {
        if (p->dato == dato) return 1;
        p = p->siguiente;
    }
    return 0;
}

int copiarDeque(const Deque* origen, Deque* destino) {
    inicializarDeque(destino);
    const NodoDeque* p = origen->frente;
    while (p) {
        if (!encolarFinal(destino, p->dato)) {
            liberarDeque(destino);
            return 0;
        }
        p = p->siguiente;
    }
    return 1;
}

void invertirDeque(Deque* d) {
    NodoDeque* act = d->frente;
    d->final = d->frente;
    while (act) {
        NodoDeque* tmp = act->siguiente;
        act->siguiente = act->anterior;
        act->anterior = tmp;
        act = tmp;
    }
    if (d->final) {
        d->frente = d->final;
        while (d->frente->anterior) d->frente = d->frente->anterior;
    }
}

void rotarDeque(Deque* d, int n) {
    if (d->tam < 2) return;
    n = n % d->tam;
    for (int i = 0; i < n; i++) {
        int val;
        if (desencolarFinal(d, &val))
            encolarFrente(d, val);
    }
}

void ordenarDeque(Deque* d) {
    if (d->tam < 2) return;
    for (NodoDeque* i = d->frente; i->siguiente; i = i->siguiente) {
        NodoDeque* min = i;
        for (NodoDeque* j = i->siguiente; j; j = j->siguiente)
            if (j->dato < min->dato) min = j;
        if (min != i) {
            int tmp = i->dato;
            i->dato = min->dato;
            min->dato = tmp;
        }
    }
}

void liberarDeque(Deque* d) {
    while (!dequeVacio(d)) {
        int tmp;
        desencolarFrente(d, &tmp);
    }
}

int main() {
    Deque dq;
    inicializarDeque(&dq);
    int opcion, valor;

    do {
        printf("\n--- MENU DEQUE (COLA DOBLE) ---\n");
        printf("1. Encolar al frente\n");
        printf("2. Encolar al final\n");
        printf("3. Desencolar del frente\n");
        printf("4. Desencolar del final\n");
        printf("5. Ver frente\n");
        printf("6. Ver final\n");
        printf("7. Mostrar deque\n");
        printf("8. Tamaño\n");
        printf("9. Buscar\n");
        printf("10. Invertir\n");
        printf("11. Rotar derecha\n");
        printf("12. Ordenar\n");
        printf("13. Copiar y mostrar copia\n");
        printf("0. Salir\n");
        printf("Elija: ");
        scanf("%d", &opcion);

        switch(opcion) {
            case 1:
                printf("Valor: "); scanf("%d", &valor);
                encolarFrente(&dq, valor);
                break;
            case 2:
                printf("Valor: "); scanf("%d", &valor);
                encolarFinal(&dq, valor);
                break;
            case 3:
                if (desencolarFrente(&dq, &valor))
                    printf("Desencolado frente: %d\n", valor);
                break;
            case 4:
                if (desencolarFinal(&dq, &valor))
                    printf("Desencolado final: %d\n", valor);
                break;
            case 5:
                if (verFrente(&dq, &valor))
                    printf("Frente: %d\n", valor);
                break;
            case 6:
                if (verFinal(&dq, &valor))
                    printf("Final: %d\n", valor);
                break;
            case 7:
                mostrarDeque(&dq);
                break;
            case 8:
                printf("Tamaño: %d\n", tamanioDeque(&dq));
                break;
            case 9:
                printf("Valor a buscar: "); scanf("%d", &valor);
                printf(buscarEnDeque(&dq, valor) ? "Encontrado\n" : "No encontrado\n");
                break;
            case 10:
                invertirDeque(&dq);
                printf("Deque invertido.\n");
                break;
            case 11: {
                int n;
                printf("Posiciones a rotar a la derecha: ");
                scanf("%d", &n);
                rotarDeque(&dq, n);
                break;
            }
            case 12:
                ordenarDeque(&dq);
                printf("Deque ordenado.\n");
                break;
            case 13: {
                Deque copia;
                if (copiarDeque(&dq, &copia)) {
                    printf("Copia: ");
                    mostrarDeque(&copia);
                    liberarDeque(&copia);
                }
                break;
            }
            case 0:
                break;
            default:
                printf("Opcion invalida\n");
        }
    } while (opcion != 0);

    liberarDeque(&dq);
    return 0;
}