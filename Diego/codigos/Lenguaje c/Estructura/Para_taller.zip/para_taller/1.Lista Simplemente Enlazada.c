#include <stdio.h>
#include <stdlib.h>

typedef struct NodoSimple {
    int dato;
    struct NodoSimple* siguiente;
} NodoSimple;

typedef struct {
    NodoSimple* cabeza;
    NodoSimple* cola;
    int tam;
} ListaSimple;

/* ---------- Inicialización ---------- */
void inicializarLista(ListaSimple* l) {
    l->cabeza = l->cola = NULL;
    l->tam = 0;
}

/* ---------- Creación de nodo (con validación) ---------- */
NodoSimple* crearNodoSimple(int dato) {
    NodoSimple* n = (NodoSimple*)malloc(sizeof(NodoSimple));
    if (!n) {
        printf("Error: memoria insuficiente para el nodo.\n");
        return NULL;
    }
    n->dato = dato;
    n->siguiente = NULL;
    return n;
}

/* ---------- Inserciones ---------- */
int insertarInicio(ListaSimple* l, int dato) {
    NodoSimple* n = crearNodoSimple(dato);
    if (!n) return 0;
    n->siguiente = l->cabeza;
    l->cabeza = n;
    if (!l->cola) l->cola = n;
    l->tam++;
    return 1;
}

int insertarFinal(ListaSimple* l, int dato) {
    NodoSimple* n = crearNodoSimple(dato);
    if (!n) return 0;
    if (!l->cola) {
        l->cabeza = l->cola = n;
    } else {
        l->cola->siguiente = n;
        l->cola = n;
    }
    l->tam++;
    return 1;
}

int insertarOrdenado(ListaSimple* l, int dato) {
    NodoSimple* n = crearNodoSimple(dato);
    if (!n) return 0;
    if (!l->cabeza || l->cabeza->dato >= dato) {
        n->siguiente = l->cabeza;
        l->cabeza = n;
        if (!l->cola) l->cola = n;
    } else {
        NodoSimple* ant = l->cabeza;
        while (ant->siguiente && ant->siguiente->dato < dato)
            ant = ant->siguiente;
        n->siguiente = ant->siguiente;
        ant->siguiente = n;
        if (!n->siguiente) l->cola = n;
    }
    l->tam++;
    return 1;
}

int insertarPosicion(ListaSimple* l, int dato, int pos) {
    if (pos < 0 || pos > l->tam) return 0;   // posición inválida
    if (pos == 0) return insertarInicio(l, dato);
    if (pos == l->tam) return insertarFinal(l, dato);
    NodoSimple* ant = l->cabeza;
    for (int i = 0; i < pos - 1; i++) ant = ant->siguiente;
    NodoSimple* n = crearNodoSimple(dato);
    if (!n) return 0;
    n->siguiente = ant->siguiente;
    ant->siguiente = n;
    l->tam++;
    return 1;
}

/* ---------- Eliminaciones ---------- */
int eliminarDato(ListaSimple* l, int dato) {
    NodoSimple *act = l->cabeza, *ant = NULL;
    while (act) {
        if (act->dato == dato) {
            if (ant) ant->siguiente = act->siguiente;
            else l->cabeza = act->siguiente;
            if (act == l->cola) l->cola = ant;
            free(act);
            l->tam--;
            return 1;
        }
        ant = act;
        act = act->siguiente;
    }
    return 0;
}

int eliminarPosicion(ListaSimple* l, int pos) {
    if (pos < 0 || pos >= l->tam) return 0;
    NodoSimple* act = l->cabeza;
    if (pos == 0) {
        l->cabeza = act->siguiente;
        if (!l->cabeza) l->cola = NULL;
        free(act);
    } else {
        NodoSimple* ant = l->cabeza;
        for (int i = 0; i < pos - 1; i++) ant = ant->siguiente;
        act = ant->siguiente;
        ant->siguiente = act->siguiente;
        if (!act->siguiente) l->cola = ant;
        free(act);
    }
    l->tam--;
    return 1;
}

/* ---------- Búsqueda y consultas ---------- */
int buscar(const ListaSimple* l, int dato) {
    const NodoSimple* act = l->cabeza;
    while (act) {
        if (act->dato == dato) return 1;
        act = act->siguiente;
    }
    return 0;
}

int longitud(const ListaSimple* l) { return l->tam; }

/* ---------- Copia ---------- */
int copiarLista(const ListaSimple* origen, ListaSimple* destino) {
    inicializarLista(destino);
    const NodoSimple* p = origen->cabeza;
    while (p) {
        if (!insertarFinal(destino, p->dato)) {
            liberarLista(destino);
            return 0;
        }
        p = p->siguiente;
    }
    return 1;
}

/* ---------- Inversión ---------- */
void invertir(ListaSimple* l) {
    NodoSimple *ant = NULL, *act = l->cabeza, *sig;
    l->cola = l->cabeza;          // el nuevo final será la antigua cabeza
    while (act) {
        sig = act->siguiente;
        act->siguiente = ant;
        ant = act;
        act = sig;
    }
    l->cabeza = ant;
}

/* ---------- Concatenación ---------- */
void concatenar(ListaSimple* l1, ListaSimple* l2) {
    if (!l2->cabeza) return;
    if (!l1->cabeza) {
        l1->cabeza = l2->cabeza;
        l1->cola = l2->cola;
    } else {
        l1->cola->siguiente = l2->cabeza;
        l1->cola = l2->cola;
    }
    l1->tam += l2->tam;
    l2->cabeza = l2->cola = NULL;
    l2->tam = 0;
}

/* ---------- MergeSort ---------- */
static void dividir(NodoSimple* cabeza, NodoSimple** izq, NodoSimple** der) {
    NodoSimple* rapido = cabeza->siguiente;
    NodoSimple* lento = cabeza;
    while (rapido) {
        rapido = rapido->siguiente;
        if (rapido) {
            lento = lento->siguiente;
            rapido = rapido->siguiente;
        }
    }
    *izq = cabeza;
    *der = lento->siguiente;
    lento->siguiente = NULL;
}

static NodoSimple* fusionarOrdenado(NodoSimple* a, NodoSimple* b) {
    if (!a) return b;
    if (!b) return a;
    if (a->dato <= b->dato) {
        a->siguiente = fusionarOrdenado(a->siguiente, b);
        return a;
    } else {
        b->siguiente = fusionarOrdenado(a, b->siguiente);
        return b;
    }
}

static void mergeSortRec(NodoSimple** cabezaRef) {
    NodoSimple* cabeza = *cabezaRef;
    if (!cabeza || !cabeza->siguiente) return;
    NodoSimple *izq, *der;
    dividir(cabeza, &izq, &der);
    mergeSortRec(&izq);
    mergeSortRec(&der);
    *cabezaRef = fusionarOrdenado(izq, der);
}

void mergeSort(ListaSimple* l) {
    mergeSortRec(&(l->cabeza));
    if (!l->cabeza) {
        l->cola = NULL;
        return;
    }
    l->cola = l->cabeza;
    while (l->cola->siguiente) l->cola = l->cola->siguiente;
}

void eliminarDuplicadosOrdenado(ListaSimple* l) {
    NodoSimple* act = l->cabeza;
    while (act && act->siguiente) {
        if (act->dato == act->siguiente->dato) {
            NodoSimple* tmp = act->siguiente;
            act->siguiente = tmp->siguiente;
            if (!act->siguiente) l->cola = act;
            free(tmp);
            l->tam--;
        } else {
            act = act->siguiente;
        }
    }
}

/* ---------- Detección de ciclos (Floyd) ---------- */
int tieneCiclo(const ListaSimple* l) {
    if (!l->cabeza) return 0;
    const NodoSimple *tortuga = l->cabeza, *liebre = l->cabeza->siguiente;
    while (liebre && liebre->siguiente) {
        if (tortuga == liebre) return 1;
        tortuga = tortuga->siguiente;
        liebre = liebre->siguiente->siguiente;
    }
    return 0;
}

/* ---------- Operaciones circulares ---------- */
void hacerCircular(ListaSimple* l) {
    if (!l->cola) return;
    l->cola->siguiente = l->cabeza;
    l->cola = NULL;   // ya no es lineal
}

void deshacerCircular(ListaSimple* l) {
    if (!l->cabeza) return;
    NodoSimple* tortuga = l->cabeza;
    NodoSimple* liebre = l->cabeza;
    while (liebre && liebre->siguiente) {
        tortuga = tortuga->siguiente;
        liebre = liebre->siguiente->siguiente;
        if (tortuga == liebre) break;
    }
    if (!liebre || !liebre->siguiente) return;   // no hay ciclo
    tortuga = l->cabeza;
    while (tortuga != liebre) {
        tortuga = tortuga->siguiente;
        liebre = liebre->siguiente;
    }
    NodoSimple* ultimo = liebre;
    while (ultimo->siguiente != liebre)
        ultimo = ultimo->siguiente;
    ultimo->siguiente = NULL;
    l->cola = ultimo;
}

/* ---------- Visualización ---------- */
void mostrarLista(const ListaSimple* l) {
    const NodoSimple* p = l->cabeza;
    while (p) {
        printf("%d -> ", p->dato);
        p = p->siguiente;
    }
    printf("NULL (tam=%d)\n", l->tam);
}

/* ---------- Liberación ---------- */
void liberarLista(ListaSimple* l) {
    NodoSimple* act = l->cabeza;
    while (act) {
        NodoSimple* tmp = act;
        act = act->siguiente;
        free(tmp);
    }
    l->cabeza = l->cola = NULL;
    l->tam = 0;
}

/* ---------- Ejemplo de uso ---------- */
int main() {
    ListaSimple lista;
    inicializarLista(&lista);
    int opcion, valor, pos;

    do {
        printf("\n--- MENU LISTA SIMPLE ---\n");
        printf("1. Insertar al inicio\n");
        printf("2. Insertar al final\n");
        printf("3. Insertar ordenado\n");
        printf("4. Insertar en posicion\n");
        printf("5. Eliminar por valor\n");
        printf("6. Eliminar por posicion\n");
        printf("7. Buscar\n");
        printf("8. Mostrar\n");
        printf("9. Invertir\n");
        printf("10. Ordenar (MergeSort)\n");
        printf("11. Copiar a otra lista\n");
        printf("12. Concatenar con lista auxiliar\n");
        printf("13. Hacer circular\n");
        printf("14. Deshacer circular\n");
        printf("15. Detectar ciclo\n");
        printf("0. Salir\n");
        printf("Elija: ");
        scanf("%d", &opcion);

        switch(opcion) {
            case 1:
                printf("Valor: "); scanf("%d", &valor);
                insertarInicio(&lista, valor);
                break;
            case 2:
                printf("Valor: "); scanf("%d", &valor);
                insertarFinal(&lista, valor);
                break;
            case 3:
                printf("Valor: "); scanf("%d", &valor);
                insertarOrdenado(&lista, valor);
                break;
            case 4:
                printf("Valor y posicion: "); scanf("%d %d", &valor, &pos);
                if (!insertarPosicion(&lista, valor, pos))
                    printf("Posicion invalida\n");
                break;
            case 5:
                printf("Valor a eliminar: "); scanf("%d", &valor);
                if (eliminarDato(&lista, valor))
                    printf("Eliminado\n");
                else
                    printf("No encontrado\n");
                break;
            case 6:
                printf("Posicion a eliminar: "); scanf("%d", &pos);
                if (!eliminarPosicion(&lista, pos))
                    printf("Posicion invalida\n");
                break;
            case 7:
                printf("Valor a buscar: "); scanf("%d", &valor);
                printf(buscar(&lista, valor) ? "Encontrado\n" : "No encontrado\n");
                break;
            case 8:
                mostrarLista(&lista);
                break;
            case 9:
                invertir(&lista);
                printf("Lista invertida.\n");
                break;
            case 10:
                mergeSort(&lista);
                printf("Ordenada con MergeSort.\n");
                break;
            case 11: {
                ListaSimple copia;
                if (copiarLista(&lista, &copia)) {
                    printf("Copia: ");
                    mostrarLista(&copia);
                    liberarLista(&copia);
                }
                break;
            }
            case 12: {
                ListaSimple aux;
                inicializarLista(&aux);
                int n;
                printf("Cuantos elementos en lista auxiliar? ");
                scanf("%d", &n);
                for (int i = 0; i < n; i++) {
                    printf("Elemento %d: ", i+1);
                    scanf("%d", &valor);
                    insertarFinal(&aux, valor);
                }
                concatenar(&lista, &aux);
                printf("Listas concatenadas.\n");
                break;
            }
            case 13:
                hacerCircular(&lista);
                printf("Lista vuelta circular (no usar mostrar normal, puede colgar).\n");
                break;
            case 14:
                deshacerCircular(&lista);
                printf("Circularidad deshecha.\n");
                break;
            case 15:
                printf(tieneCiclo(&lista) ? "Tiene ciclo\n" : "No tiene ciclo\n");
                break;
            case 0:
                break;
            default:
                printf("Opcion invalida\n");
        }
    } while (opcion != 0);

    liberarLista(&lista);
    return 0;
}