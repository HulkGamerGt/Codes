#include <stdio.h>
#include <stdlib.h>

typedef struct NodoPila {
    int dato;
    struct NodoPila* siguiente;
} NodoPila;

typedef struct {
    NodoPila* tope;
    int tam;
} Pila;

void inicializarPila(Pila* p) { p->tope = NULL; p->tam = 0; }
int pilaVacia(const Pila* p) { return p->tope == NULL; }

int apilar(Pila* p, int dato) {
    NodoPila* n = (NodoPila*)malloc(sizeof(NodoPila));
    if (!n) {
        printf("Error: memoria insuficiente para apilar.\n");
        return 0;
    }
    n->dato = dato;
    n->siguiente = p->tope;
    p->tope = n;
    p->tam++;
    return 1;
}

int desapilar(Pila* p, int* dato) {
    if (pilaVacia(p)) {
        printf("Error: pila vacía.\n");
        return 0;
    }
    NodoPila* tmp = p->tope;
    *dato = tmp->dato;
    p->tope = tmp->siguiente;
    free(tmp);
    p->tam--;
    return 1;
}

int verTope(const Pila* p, int* dato) {
    if (pilaVacia(p)) return 0;
    *dato = p->tope->dato;
    return 1;
}

int tamanioPila(const Pila* p) { return p->tam; }

void mostrarPila(const Pila* p) {
    const NodoPila* aux = p->tope;
    printf("Tope -> ");
    while (aux) {
        printf("%d ", aux->dato);
        aux = aux->siguiente;
    }
    printf("(tam=%d)\n", p->tam);
}

int copiarPila(const Pila* origen, Pila* destino) {
    inicializarPila(destino);
    if (pilaVacia(origen)) return 1;
    Pila aux;
    inicializarPila(&aux);
    const NodoPila* cur = origen->tope;
    while (cur) {
        apilar(&aux, cur->dato);
        cur = cur->siguiente;
    }
    while (!pilaVacia(&aux)) {
        int val;
        desapilar(&aux, &val);
        apilar(destino, val);
    }
    return 1;
}

void invertirPilaReal(Pila* p) {
    if (pilaVacia(p)) return;
    NodoPila *ant = NULL, *act = p->tope, *sig;
    while (act) {
        sig = act->siguiente;
        act->siguiente = ant;
        ant = act;
        act = sig;
    }
    p->tope = ant;
}

void invertirPila(Pila* p) { invertirPilaReal(p); }

void ordenarPila(Pila* p) {
    Pila aux;
    inicializarPila(&aux);
    while (!pilaVacia(p)) {
        int tmp;
        desapilar(p, &tmp);
        while (!pilaVacia(&aux)) {
            int topAux;
            verTope(&aux, &topAux);
            if (topAux < tmp) break;
            desapilar(&aux, &topAux);
            apilar(p, topAux);
        }
        apilar(&aux, tmp);
    }
    p->tope = aux.tope;
    p->tam = aux.tam;
    aux.tope = NULL;
    aux.tam = 0;
}

int pilasIguales(const Pila* a, const Pila* b) {
    if (a->tam != b->tam) return 0;
    const NodoPila *pa = a->tope, *pb = b->tope;
    while (pa && pb) {
        if (pa->dato != pb->dato) return 0;
        pa = pa->siguiente;
        pb = pb->siguiente;
    }
    return 1;
}

void duplicarTope(Pila* p) {
    if (pilaVacia(p)) return;
    int val;
    verTope(p, &val);
    apilar(p, val);
}

void intercambiarTopes(Pila* p) {
    if (tamanioPila(p) < 2) return;
    int a, b;
    desapilar(p, &a);
    desapilar(p, &b);
    apilar(p, a);
    apilar(p, b);
}

void vaciarPila(Pila* p) {
    while (!pilaVacia(p)) {
        int tmp;
        desapilar(p, &tmp);
    }
}

void liberarPila(Pila* p) { vaciarPila(p); }

int main() {
    Pila p;
    inicializarPila(&p);
    int opcion, valor;

    do {
        printf("\n--- MENU PILA ---\n");
        printf("1. Apilar\n");
        printf("2. Desapilar\n");
        printf("3. Ver tope\n");
        printf("4. Mostrar pila\n");
        printf("5. Tamaño\n");
        printf("6. Invertir\n");
        printf("7. Ordenar\n");
        printf("8. Duplicar tope\n");
        printf("9. Intercambiar topes\n");
        printf("10. Copiar y mostrar copia\n");
        printf("11. Comparar con otra pila\n");
        printf("12. Vaciar\n");
        printf("0. Salir\n");
        printf("Elija: ");
        scanf("%d", &opcion);

        switch(opcion) {
            case 1:
                printf("Valor: "); scanf("%d", &valor);
                apilar(&p, valor);
                break;
            case 2:
                if (desapilar(&p, &valor))
                    printf("Desapilado: %d\n", valor);
                break;
            case 3:
                if (verTope(&p, &valor))
                    printf("Tope: %d\n", valor);
                break;
            case 4:
                mostrarPila(&p);
                break;
            case 5:
                printf("Tamaño: %d\n", tamanioPila(&p));
                break;
            case 6:
                invertirPila(&p);
                printf("Pila invertida.\n");
                break;
            case 7:
                ordenarPila(&p);
                printf("Pila ordenada (menor en tope).\n");
                break;
            case 8:
                duplicarTope(&p);
                printf("Tope duplicado.\n");
                break;
            case 9:
                if (tamanioPila(&p) >= 2) {
                    intercambiarTopes(&p);
                    printf("Topes intercambiados.\n");
                } else {
                    printf("Se necesitan al menos dos elementos.\n");
                }
                break;
            case 10: {
                Pila copia;
                copiarPila(&p, &copia);
                printf("Copia: ");
                mostrarPila(&copia);
                liberarPila(&copia);
                break;
            }
            case 11: {
                Pila otra;
                inicializarPila(&otra);
                int n;
                printf("Cuantos elementos en la otra pila? ");
                scanf("%d", &n);
                for (int i=0; i<n; i++) {
                    printf("Elemento %d: ", i+1);
                    scanf("%d", &valor);
                    apilar(&otra, valor);
                }
                printf("Las pilas son %s\n", pilasIguales(&p, &otra) ? "iguales" : "diferentes");
                liberarPila(&otra);
                break;
            }
            case 12:
                vaciarPila(&p);
                printf("Pila vaciada.\n");
                break;
            case 0:
                break;
            default:
                printf("Opcion invalida\n");
        }
    } while (opcion != 0);

    liberarPila(&p);
    return 0;
}